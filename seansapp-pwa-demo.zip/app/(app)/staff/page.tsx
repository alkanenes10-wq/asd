"use client";

import { useState } from "react";
import { Plus, Pencil, Trash2, Globe } from "lucide-react";
import { useLang } from "@/components/i18n/language-provider";
import { useAppUI } from "@/components/app/app-shell";
import { Modal, FormField, selectClass, Toggle } from "@/components/app/modal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { minutesToHHMM } from "@/lib/utils";
import { useDb, saveStaff, deleteStaff } from "@/lib/demo/store";
import { dayStartMin, dayEndMin, type Staff } from "@/lib/demo/data";

/** Çalışma saati seçenekleri: takvim ızgarasının sınırları içinde, 30 dk adımla. */
const HOURS: number[] = [];
for (let m = dayStartMin; m <= dayEndMin; m += 30) HOURS.push(m);

/**
 * Kurulum › Hekimler. Takvimdeki sütunlar, çalışma saatleri ve randevu
 * sayfasında kimin görüneceği buradan yönetilir.
 */
export default function StaffPage() {
  const { t } = useLang();
  const { staff, appointments } = useDb();
  const { toast } = useAppUI();
  const [editing, setEditing] = useState<Staff | "new" | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);

  function remove(s: Staff) {
    if (deleteStaff(s.id)) {
      toast(`${s.name} silindi`);
    } else {
      toast(staff.length <= 1 ? "En az bir hekim kalmalı" : `${s.name} silinemedi — takvimde randevuları var`);
    }
    setConfirmId(null);
  }

  return (
    <div className="mx-auto max-w-4xl animate-fade-in space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Hekimler</h1>
          <p className="mt-0.5 text-sm text-muted-foreground">
            {staff.length} kişi · her biri takvimde kendi sütununda görünür.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setEditing("new")}
          className="ml-auto inline-flex h-9 cursor-pointer items-center gap-1.5 rounded-lg bg-primary px-3.5 text-[13px] font-semibold text-primary-foreground shadow-sm transition-opacity hover:opacity-90"
        >
          <Plus className="h-4 w-4" />
          Hekim ekle
        </button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {staff.map((s) => {
          const today = appointments.filter((a) => a.staffId === s.id && a.dayOffset === 0).length;
          const bookable = s.bookable !== false;
          return (
            <div key={s.id} className="rounded-2xl border border-border bg-card p-4 shadow-soft">
              <div className="flex items-center gap-3">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full text-sm font-bold text-white" style={{ backgroundImage: "var(--grad-brand)" }}>
                  {s.initials}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[14.5px] font-semibold leading-tight">{s.name}</p>
                  <p className="truncate text-[12px] text-muted-foreground">{t(s.role)}</p>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setEditing(s)}
                    aria-label={`${s.name} düzenle`}
                    className="grid h-8 w-8 cursor-pointer place-items-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                  >
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmId(s.id)}
                    aria-label={`${s.name} sil`}
                    className="grid h-8 w-8 cursor-pointer place-items-center rounded-lg text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <div className="mt-3.5 grid grid-cols-2 gap-2.5">
                <div className="rounded-xl border border-border px-3 py-2">
                  <p className="text-[10.5px] text-muted-foreground">Çalışma saatleri</p>
                  <p className="tnum mt-0.5 text-[13px] font-semibold">
                    {minutesToHHMM(s.startMin)} – {minutesToHHMM(s.endMin)}
                  </p>
                </div>
                <div className="rounded-xl border border-border px-3 py-2">
                  <p className="text-[10.5px] text-muted-foreground">Bugün</p>
                  <p className="tnum mt-0.5 text-[13px] font-semibold">{today} randevu</p>
                </div>
              </div>

              <p className="mt-3 inline-flex items-center gap-1.5 text-[12px] text-muted-foreground">
                <Globe className={bookable ? "h-3.5 w-3.5 text-success" : "h-3.5 w-3.5"} />
                {bookable ? "Randevu sayfasında görünüyor" : "Randevu sayfasında gizli"}
              </p>

              {confirmId === s.id && (
                <div className="mt-3 rounded-lg border border-destructive/30 bg-destructive/[0.04] p-3">
                  <p className="text-[12.5px] font-medium">{s.name} silinsin mi?</p>
                  <div className="mt-2 grid grid-cols-2 gap-2">
                    <button type="button" onClick={() => setConfirmId(null)} className="cursor-pointer rounded-lg border border-border bg-card py-2 text-[12.5px] font-semibold transition-colors hover:bg-muted">
                      Vazgeç
                    </button>
                    <button type="button" onClick={() => remove(s)} className="cursor-pointer rounded-lg bg-destructive py-2 text-[12.5px] font-semibold text-destructive-foreground transition-opacity hover:opacity-90">
                      Evet, sil
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {editing && (
        <StaffModal
          person={editing === "new" ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={(name, isNew) => {
            setEditing(null);
            toast(isNew ? `${name} eklendi — takvimde yeni bir sütunu var` : `${name} güncellendi`);
          }}
        />
      )}
    </div>
  );
}

function StaffModal({
  person,
  onClose,
  onSaved,
}: {
  person: Staff | null;
  onClose: () => void;
  onSaved: (name: string, isNew: boolean) => void;
}) {
  const [name, setName] = useState(person?.name ?? "");
  const [role, setRole] = useState(person?.role.tr ?? "Diş hekimi");
  const [startMin, setStartMin] = useState(person?.startMin ?? 9 * 60);
  const [endMin, setEndMin] = useState(person?.endMin ?? 18 * 60);
  const [bookable, setBookable] = useState(person ? person.bookable !== false : true);
  const [touched, setTouched] = useState(false);

  const nameOk = name.trim().length >= 3;
  const hoursOk = endMin - startMin >= 60;

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setTouched(true);
    if (!nameOk || !hoursOk) return;
    const cleanRole = role.trim() || "Diş hekimi";
    saveStaff({
      id: person?.id,
      name: name.trim(),
      role: { tr: cleanRole, en: person && person.role.tr === cleanRole ? person.role.en : cleanRole },
      startMin,
      endMin,
      bookable,
    });
    onSaved(name.trim(), !person);
  }

  return (
    <Modal title={person ? "Hekimi düzenle" : "Hekim ekle"} onClose={onClose}>
      <form onSubmit={submit} className="space-y-4" noValidate>
        <FormField label="Ad Soyad" htmlFor="h-ad" error={touched && !nameOk ? "Hekimin adını yazın." : null}>
          <Input id="h-ad" value={name} onChange={(e) => setName(e.target.value)} placeholder="Dt. Ayşe Yılmaz" autoFocus />
        </FormField>
        <FormField label="Unvan / branş" htmlFor="h-rol">
          <Input id="h-rol" list="h-roller" value={role} onChange={(e) => setRole(e.target.value)} placeholder="Diş hekimi" />
          <datalist id="h-roller">
            <option value="Diş hekimi" />
            <option value="Ortodonti uzmanı" />
            <option value="Çene cerrahı" />
            <option value="Pedodonti uzmanı" />
            <option value="Endodonti uzmanı" />
            <option value="Ağız-diş sağlığı asistanı" />
          </datalist>
        </FormField>
        <div className="grid grid-cols-2 gap-3">
          <FormField label="Başlangıç" htmlFor="h-bas">
            <select id="h-bas" className={selectClass} value={startMin} onChange={(e) => setStartMin(Number(e.target.value))}>
              {HOURS.slice(0, -1).map((m) => (
                <option key={m} value={m}>
                  {minutesToHHMM(m)}
                </option>
              ))}
            </select>
          </FormField>
          <FormField label="Bitiş" htmlFor="h-bit" error={touched && !hoursOk ? "Bitiş, başlangıçtan en az 1 saat sonra olmalı." : null}>
            <select id="h-bit" className={selectClass} value={endMin} onChange={(e) => setEndMin(Number(e.target.value))}>
              {HOURS.slice(1).map((m) => (
                <option key={m} value={m}>
                  {minutesToHHMM(m)}
                </option>
              ))}
            </select>
          </FormField>
        </div>
        <div className="flex items-center gap-3 rounded-xl border border-border p-3">
          <div className="min-w-0 flex-1">
            <p className="text-[13px] font-medium">Online randevu alabilsin</p>
            <p className="text-[11.5px] text-muted-foreground">Kapalıysa hastalar randevu sayfasında bu kişiyi göremez.</p>
          </div>
          <Toggle checked={bookable} onChange={setBookable} label="Online randevu alabilsin" />
        </div>
        <div className="flex gap-2 pt-1">
          <Button type="button" variant="outline" className="flex-1" onClick={onClose}>
            Vazgeç
          </Button>
          <Button type="submit" className="flex-1">
            Kaydet
          </Button>
        </div>
      </form>
    </Modal>
  );
}
