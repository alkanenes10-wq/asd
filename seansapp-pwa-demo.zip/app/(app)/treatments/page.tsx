"use client";

import { useState } from "react";
import { Plus, Pencil, Trash2, Clock } from "lucide-react";
import { useLang } from "@/components/i18n/language-provider";
import { useAppUI } from "@/components/app/app-shell";
import { Modal, FormField, selectClass } from "@/components/app/modal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn, formatDuration } from "@/lib/utils";
import { useDb, saveService, deleteService } from "@/lib/demo/store";
import { SERVICE_VAR, type Service, type ServiceColor } from "@/lib/demo/data";

const COLORS: { key: ServiceColor; label: string }[] = [
  { key: "muayene", label: "Mavi" },
  { key: "temizlik", label: "Turkuaz" },
  { key: "dolgu", label: "Mor" },
  { key: "kanal", label: "Lacivert" },
  { key: "implant", label: "Amber" },
  { key: "ortodonti", label: "Yeşil" },
];

const DURATIONS = [10, 15, 20, 30, 45, 60, 75, 90, 120];

/**
 * Kurulum › Tedaviler. Kliniğin sunduğu tedaviler, süreleri ve takvim renkleri.
 * Buradaki liste randevu sayfasında hastaya gösterilen seçeneklerin de kaynağı.
 */
export default function TreatmentsPage() {
  const { t } = useLang();
  const { services, appointments } = useDb();
  const { toast } = useAppUI();
  const [editing, setEditing] = useState<Service | "new" | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);

  function remove(s: Service) {
    if (deleteService(s.id)) {
      toast(`${t(s.name)} silindi`);
    } else {
      toast(
        services.length <= 1
          ? "En az bir tedavi kalmalı"
          : `${t(s.name)} silinemedi — bu tedaviye ait randevular var`,
      );
    }
    setConfirmId(null);
  }

  return (
    <div className="mx-auto max-w-4xl animate-fade-in space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Tedaviler</h1>
          <p className="mt-0.5 text-sm text-muted-foreground">
            {services.length} tedavi · süreler takvimde ve randevu sayfasında otomatik kullanılır.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setEditing("new")}
          className="ml-auto inline-flex h-9 cursor-pointer items-center gap-1.5 rounded-lg bg-primary px-3.5 text-[13px] font-semibold text-primary-foreground shadow-sm transition-opacity hover:opacity-90"
        >
          <Plus className="h-4 w-4" />
          Tedavi ekle
        </button>
      </div>

      <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-soft">
        <div className="divide-y divide-border/60">
          {services.map((s) => {
            const upcoming = appointments.filter((a) => a.serviceId === s.id && a.dayOffset >= 0).length;
            return (
              <div key={s.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
                <span className="h-9 w-1.5 shrink-0 rounded-full" style={{ background: SERVICE_VAR[s.color] }} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[14px] font-semibold">{t(s.name)}</p>
                  <p className="tnum text-[11.5px] text-muted-foreground">
                    {upcoming > 0 ? `${upcoming} yaklaşan randevu` : "yaklaşan randevu yok"}
                    {s.bookings30d > 0 && ` · son 30 günde ${s.bookings30d}`}
                  </p>
                </div>
                <span className="tnum inline-flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 text-[12px] font-semibold text-muted-foreground">
                  <Clock className="h-3.5 w-3.5" />
                  {formatDuration(s.durationMin)}
                </span>
                {confirmId === s.id ? (
                  <div className="flex items-center gap-1.5">
                    <button type="button" onClick={() => setConfirmId(null)} className="h-8 cursor-pointer rounded-lg border border-border px-2.5 text-[12px] font-semibold transition-colors hover:bg-muted">
                      Vazgeç
                    </button>
                    <button type="button" onClick={() => remove(s)} className="h-8 cursor-pointer rounded-lg bg-destructive px-2.5 text-[12px] font-semibold text-destructive-foreground transition-opacity hover:opacity-90">
                      Sil
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setEditing(s)}
                      aria-label={`${t(s.name)} düzenle`}
                      className="grid h-8 w-8 cursor-pointer place-items-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                    >
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmId(s.id)}
                      aria-label={`${t(s.name)} sil`}
                      className="grid h-8 w-8 cursor-pointer place-items-center rounded-lg text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {editing && (
        <ServiceModal
          service={editing === "new" ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={(name, isNew) => {
            setEditing(null);
            toast(isNew ? `${name} eklendi — randevu sayfasında da görünüyor` : `${name} güncellendi`);
          }}
        />
      )}
    </div>
  );
}

function ServiceModal({
  service,
  onClose,
  onSaved,
}: {
  service: Service | null;
  onClose: () => void;
  onSaved: (name: string, isNew: boolean) => void;
}) {
  const [name, setName] = useState(service?.name.tr ?? "");
  const [durationMin, setDurationMin] = useState(service?.durationMin ?? 30);
  const [color, setColor] = useState<ServiceColor>(service?.color ?? "muayene");
  const [touched, setTouched] = useState(false);
  const nameOk = name.trim().length >= 2;
  const durations = DURATIONS.includes(durationMin) ? DURATIONS : [...DURATIONS, durationMin].sort((a, b) => a - b);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setTouched(true);
    if (!nameOk) return;
    const clean = name.trim();
    saveService({
      id: service?.id,
      // EN alanı ileride açılacak İngilizce arayüz için; düzenlenen adla aynı tutulur.
      name: { tr: clean, en: service && service.name.tr === clean ? service.name.en : clean },
      durationMin,
      color,
    });
    onSaved(clean, !service);
  }

  return (
    <Modal title={service ? "Tedaviyi düzenle" : "Tedavi ekle"} onClose={onClose}>
      <form onSubmit={submit} className="space-y-4" noValidate>
        <FormField label="Tedavi adı" htmlFor="t-ad" error={touched && !nameOk ? "Tedavinin adını yazın." : null}>
          <Input id="t-ad" value={name} onChange={(e) => setName(e.target.value)} placeholder="Örn. Zirkonyum kaplama" autoFocus />
        </FormField>
        <FormField label="Süre" htmlFor="t-sure" hint="Takvimde bu kadar yer ayrılır.">
          <select id="t-sure" className={selectClass} value={durationMin} onChange={(e) => setDurationMin(Number(e.target.value))}>
            {durations.map((d) => (
              <option key={d} value={d}>
                {formatDuration(d)}
              </option>
            ))}
          </select>
        </FormField>
        <FormField label="Takvim rengi">
          <div className="flex flex-wrap gap-2">
            {COLORS.map((c) => (
              <button
                key={c.key}
                type="button"
                aria-pressed={color === c.key}
                onClick={() => setColor(c.key)}
                className={cn(
                  "inline-flex cursor-pointer items-center gap-2 rounded-lg border px-2.5 py-1.5 text-[12.5px] font-medium transition-colors",
                  color === c.key ? "border-primary bg-primary/[0.06] text-foreground" : "border-border text-muted-foreground hover:bg-muted",
                )}
              >
                <span className="h-3 w-3 rounded-[4px]" style={{ background: SERVICE_VAR[c.key] }} />
                {c.label}
              </button>
            ))}
          </div>
        </FormField>
        <div className="flex gap-2 pt-1">
          <Button type="button" variant="outline" className="flex-1" onClick={onClose}>
            Vazgeç
          </Button>
          <Button type="submit" className="flex-1">
            Kaydet
          </Button>
        </div>
      </form>
    </Modal>
  );
}
