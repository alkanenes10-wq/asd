"use client";

import { useEffect, useState } from "react";
import { Search, Plus, X, Phone, Mail, Star, CalendarCheck } from "lucide-react";
import { useLang } from "@/components/i18n/language-provider";
import { cn, minutesToHHMM, formatDate } from "@/lib/utils";
import { dayLabel } from "@/lib/dates";
import { isValidTrPhone, formatTrPhone } from "@/lib/booking";
import { useDb, addClient } from "@/lib/demo/store";
import { useAppUI } from "@/components/app/app-shell";
import { Modal, FormField } from "@/components/app/modal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  CLIENT_TAG,
  serviceById,
  SERVICE_VAR,
  STATUS_META,
  type Client,
} from "@/lib/demo/data";

export default function ClientsPage() {
  const { t } = useLang();
  const [query, setQuery] = useState("");
  const [tagFilter, setTagFilter] = useState<Client["tag"] | null>(null);
  const { clients, appointments } = useDb();
  const { newAppointment, toast, focusClientId, clearFocusClient } = useAppUI();
  const [selectedId, setSelectedId] = useState<string | null>(focusClientId ?? clients[0]?.id ?? null);
  const [adding, setAdding] = useState(false);
  const selected = clients.find((c) => c.id === selectedId) ?? null;
  const setSelected = (c: Client | null) => setSelectedId(c?.id ?? null);

  // Üst menüdeki "Hasta ara"dan seçilen hasta burada açılır.
  const [lastFocus, setLastFocus] = useState<string | null>(focusClientId);
  if (focusClientId !== lastFocus) {
    setLastFocus(focusClientId);
    if (focusClientId) {
      setSelectedId(focusClientId);
      setQuery("");
      setTagFilter(null);
    }
  }
  useEffect(() => {
    if (focusClientId) clearFocusClient();
  }, [focusClientId, clearFocusClient]);

  const rows = clients.filter((c) => {
    if (tagFilter && c.tag !== tagFilter) return false;
    if (!query) return true;
    const q = query.trim().toLocaleLowerCase("tr-TR");
    const digits = q.replace(/\D/g, "");
    return (
      c.name.toLocaleLowerCase("tr-TR").includes(q) ||
      c.email.toLowerCase().includes(q) ||
      (digits.length > 2 && c.phone.replace(/\D/g, "").includes(digits))
    );
  });

  // Appointment history for the selected client (match by name in demo data).
  const history = selected
    ? appointments.filter((a) => a.client === selected.name).sort((a, b) => b.dayOffset - a.dayOffset || b.startMin - a.startMin)
    : [];

  const totalClients = clients.length;
  const newCount = clients.filter((c) => c.tag === "new").length;

  return (
    <div className="mx-auto max-w-[1400px] animate-fade-in">
      <div className={cn("grid gap-6", selected ? "xl:grid-cols-[1fr_360px]" : "grid-cols-1")}>
        {/* Main */}
        <div className="min-w-0 space-y-6">
          <div className="flex flex-wrap items-center gap-3">
            <div>
              <h1 className="font-display text-2xl font-bold tracking-tight">Hastalar</h1>
              <p className="mt-0.5 text-sm text-muted-foreground">
                {totalClients} hasta · bu hafta {newCount} yeni
              </p>
            </div>
            <button
              type="button"
              onClick={() => setAdding(true)}
              className="ml-auto inline-flex h-9 cursor-pointer items-center gap-1.5 rounded-lg bg-primary px-3.5 text-[13px] font-semibold text-primary-foreground shadow-sm transition-opacity hover:opacity-90"
            >
              <Plus className="h-4 w-4" />
              Hasta ekle
            </button>
          </div>

          {/* Controls */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex h-9 items-center gap-2 rounded-lg border border-border bg-card px-3 text-sm">
              <Search className="h-4 w-4 text-muted-foreground" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="İsim, telefon veya e-posta…"
                className="w-40 bg-transparent text-foreground placeholder:text-muted-foreground/70 focus:outline-none sm:w-56"
              />
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                onClick={() => setTagFilter(null)}
                className={cn("cursor-pointer rounded-full border px-2.5 py-1 text-[12px] font-medium transition-colors", !tagFilter ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:bg-muted")}
              >
                Hepsi
              </button>
              {(["vip", "regular", "new", "lapsed"] as Client["tag"][]).map((tg) => (
                <button
                  key={tg}
                  onClick={() => setTagFilter(tg)}
                  className={cn("cursor-pointer rounded-full border px-2.5 py-1 text-[12px] font-medium capitalize transition-colors", tagFilter === tg ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:bg-muted")}
                >
                  {t(CLIENT_TAG[tg].label)}
                </button>
              ))}
            </div>
          </div>

          {/* Table */}
          <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-soft">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-left">
                    <th className="label-mono py-2.5 pl-4 font-medium text-muted-foreground">Hasta</th>
                    <th className="label-mono hidden py-2.5 font-medium text-muted-foreground sm:table-cell">Etiket</th>
                    <th className="label-mono hidden py-2.5 font-medium text-muted-foreground md:table-cell">Son geliş</th>
                    <th className="label-mono py-2.5 text-right font-medium text-muted-foreground">Geliş</th>
                    <th className="label-mono py-2.5 pr-4 text-right font-medium text-muted-foreground">Telefon</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.length === 0 && (
                    <tr><td colSpan={5} className="py-10 text-center text-sm text-muted-foreground">Eşleşen hasta yok.</td></tr>
                  )}
                  {rows.map((c) => {
                    const tag = CLIENT_TAG[c.tag];
                    const isSel = selected?.id === c.id;
                    return (
                      <tr
                        key={c.id}
                        onClick={() => setSelected(c)}
                        className={cn("cursor-pointer border-b border-border/60 transition-colors last:border-0", isSel ? "bg-primary/[0.04]" : "hover:bg-muted/50")}
                      >
                        <td className="py-3 pl-4">
                          <div className="flex items-center gap-2.5">
                            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-muted text-[11px] font-bold text-foreground/70 ring-1 ring-border">{c.initials}</span>
                            <div className="min-w-0">
                              <p className="font-semibold leading-tight">{c.name}</p>
                              <p className="truncate text-[11px] text-muted-foreground">{c.email || "e-posta yok"}</p>
                            </div>
                          </div>
                        </td>
                        <td className="hidden py-3 sm:table-cell">
                          <span className={cn("inline-flex rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase", tag.tone)}>{t(tag.label)}</span>
                        </td>
                        <td className="tnum hidden py-3 text-muted-foreground md:table-cell">{formatDate(c.lastVisit)}</td>
                        <td className="tnum py-3 text-right text-muted-foreground">{c.visits}</td>
                        <td className="tnum py-3 pr-4 text-right text-[12.5px] text-muted-foreground">{c.phone}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Drawer */}
        {selected && (
          <aside className="animate-float-up xl:sticky xl:top-2 xl:self-start">
            <div className="space-y-5 rounded-2xl border border-border bg-card p-5 shadow-soft">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-[15px] font-semibold tracking-tight">Hasta kartı</h2>
                <button onClick={() => setSelected(null)} aria-label="Kapat" className="grid h-7 w-7 cursor-pointer place-items-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground">
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="flex items-center gap-3">
                <span className="grid h-12 w-12 place-items-center rounded-full text-base font-bold text-white" style={{ backgroundImage: "var(--grad-brand)" }}>{selected.initials}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold leading-tight">{selected.name}</p>
                  <span className={cn("mt-0.5 inline-flex rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase", CLIENT_TAG[selected.tag].tone)}>{t(CLIENT_TAG[selected.tag].label)}</span>
                </div>
              </div>

              <div className="space-y-2 text-[13px]">
                <a href={`tel:${selected.phone.replace(/\s/g, "")}`} className="flex items-center gap-2.5 text-muted-foreground transition-colors hover:text-foreground">
                  <Phone className="h-4 w-4" /> <span className="tnum">{selected.phone}</span>
                </a>
                {selected.email && (
                  <a href={`mailto:${selected.email}`} className="flex items-center gap-2.5 text-muted-foreground transition-colors hover:text-foreground">
                    <Mail className="h-4 w-4" /> {selected.email}
                  </a>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Stat label="Toplam geliş" value={String(selected.visits)} />
                <Stat label="Son geliş" value={formatDate(selected.lastVisit, { day: "2-digit", month: "short" })} />
              </div>

              {/* Randevu geçmişi */}
              <div>
                <p className="label-mono text-muted-foreground">Randevu geçmişi</p>
                <div className="mt-2.5 space-y-2">
                  {history.length === 0 && (
                    <p className="text-[13px] text-muted-foreground">Yakın tarihli randevusu yok.</p>
                  )}
                  {history.map((a) => {
                    const svc = serviceById(a.serviceId);
                    const st = STATUS_META[a.status];
                    return (
                      <div key={a.id} className="flex items-center gap-2.5 rounded-xl border border-border p-2.5">
                        <span className="h-7 w-1.5 rounded-full" style={{ background: SERVICE_VAR[svc.color] }} />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-[13px] font-medium">{t(svc.name)}</p>
                          <p className="tnum text-[11px] text-muted-foreground">{dayLabel(a.dayOffset)} · {minutesToHHMM(a.startMin)}</p>
                        </div>
                        <span className={cn("inline-flex rounded-full px-2 py-0.5 text-[9px] font-semibold", st.tone)}>{t(st.label)}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              <button
                type="button"
                onClick={() => newAppointment({ client: selected.name, phone: selected.phone })}
                className="flex w-full cursor-pointer items-center justify-center gap-1.5 rounded-lg bg-primary py-2.5 text-[13px] font-semibold text-primary-foreground transition-opacity hover:opacity-90"
              >
                <CalendarCheck className="h-4 w-4" />
                Randevu oluştur
              </button>
            </div>

            {/* Takip notu */}
            <div className="mt-4 flex items-center gap-3 rounded-2xl border border-border bg-card p-4 shadow-soft">
              <span className="grid h-9 w-9 place-items-center rounded-lg bg-warning/15 text-warning-foreground">
                <Star className="h-4 w-4" />
              </span>
              <p className="text-[12.5px] text-muted-foreground">
                {selected.tag === "vip"
                  ? "Düzenli takip hastası — 6 aylık kontrol randevusunu hatırlat."
                  : selected.tag === "lapsed"
                    ? "Uzun süredir gelmedi — kontrol için bir hatırlatma gönder."
                    : "Kontrol randevusu zamanı geldiğinde otomatik hatırlatılır."}
              </p>
            </div>
          </aside>
        )}
      </div>

      {adding && (
        <AddClientModal
          onClose={() => setAdding(false)}
          onSaved={(c) => {
            setAdding(false);
            setSelectedId(c.id);
            setQuery("");
            setTagFilter(null);
            toast(`${c.name} hasta listesine eklendi`);
          }}
        />
      )}
    </div>
  );
}

function AddClientModal({ onClose, onSaved }: { onClose: () => void; onSaved: (c: Client) => void }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [touched, setTouched] = useState(false);

  const nameOk = name.trim().length >= 3;
  const phoneOk = isValidTrPhone(phone);
  const emailOk = !email.trim() || /^\S+@\S+\.\S+$/.test(email.trim());

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setTouched(true);
    if (!nameOk || !phoneOk || !emailOk) return;
    onSaved(addClient({ name, phone: formatTrPhone(phone), email }));
  }

  return (
    <Modal title="Hasta ekle" subtitle="Randevu için yalnızca ad ve telefon yeterli." onClose={onClose}>
      <form onSubmit={submit} className="space-y-4" noValidate>
        <FormField label="Ad Soyad" htmlFor="h-ad" error={touched && !nameOk ? "Hastanın adını yazın." : null}>
          <Input id="h-ad" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ayşe Yılmaz" autoFocus />
        </FormField>
        <FormField label="Telefon" htmlFor="h-tel" error={touched && !phoneOk ? "Geçerli bir cep telefonu girin (05XX XXX XX XX)." : null}>
          <Input id="h-tel" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="0532 111 22 33" />
        </FormField>
        <FormField label="E-posta (isteğe bağlı)" htmlFor="h-mail" error={touched && !emailOk ? "E-posta adresi geçerli görünmüyor." : null}>
          <Input id="h-mail" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="ayse@example.com" />
        </FormField>
        <div className="flex gap-2 pt-1">
          <Button type="button" variant="outline" className="flex-1" onClick={onClose}>
            Vazgeç
          </Button>
          <Button type="submit" className="flex-1">
            <Plus className="h-4 w-4" />
            Hastayı kaydet
          </Button>
        </div>
      </form>
    </Modal>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-border p-3 text-center">
      <p className="tnum text-[15px] font-bold leading-none">{value}</p>
      <p className="mt-1 text-[10px] text-muted-foreground">{label}</p>
    </div>
  );
}
