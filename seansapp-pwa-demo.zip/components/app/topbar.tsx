"use client";

import { useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import Link from "next/link";
import { Bell, Menu, Plus } from "lucide-react";
import appConfig from "@/app.config";
import { Logo } from "@/components/ui/logo";
import { useLang } from "@/components/i18n/language-provider";
import { useAppUI } from "@/components/app/app-shell";
import { useDb } from "@/lib/demo/store";
import { activity, serviceById } from "@/lib/demo/data";
import { dayLabel } from "@/lib/dates";
import { cn, formatDate, minutesToHHMM } from "@/lib/utils";

/**
 * Uygulama üst çubuğu. Marka adı her ekran boyutunda ve her sayfada solda durur
 * (istenen "üstte isim" kuralı); yanında ince bir ayraçla aktif sayfanın başlığı
 * gelir. Sağda yeni randevu ve bildirimler; telefonda solda menü düğmesi.
 */
export function Topbar() {
  const pathname = usePathname();
  const { t } = useLang();
  const { newAppointment, openMenu } = useAppUI();
  const current =
    appConfig.nav.find((n) => pathname === n.href || pathname.startsWith(n.href + "/")) ??
    appConfig.navGroups.flatMap((g) => g.items).find((n) => pathname === n.href || pathname.startsWith(n.href + "/"));

  return (
    <header className="sticky top-0 z-20 flex h-14 shrink-0 items-center gap-2.5 border-b border-border bg-background/80 px-3 backdrop-blur sm:gap-3 sm:px-5 lg:px-8">
      <button
        type="button"
        onClick={openMenu}
        aria-label="Menüyü aç"
        className="grid h-9 w-9 shrink-0 cursor-pointer place-items-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground md:hidden"
      >
        <Menu className="h-5 w-5" />
      </button>

      <Link href="/dashboard" className="inline-flex shrink-0 items-center" aria-label={appConfig.name}>
        <Logo />
      </Link>

      {current && (
        <>
          <span aria-hidden className="h-4 w-px shrink-0 bg-border" />
          <span className="truncate text-[14px] font-medium text-muted-foreground">{t(current.label)}</span>
        </>
      )}

      <div className="ml-auto flex items-center gap-1.5">
        <button
          type="button"
          onClick={() => newAppointment()}
          aria-label="Yeni randevu"
          className="inline-flex h-9 cursor-pointer items-center gap-1.5 rounded-lg bg-primary px-2.5 text-[13px] font-semibold text-primary-foreground shadow-sm transition-opacity hover:opacity-90 sm:px-3.5"
        >
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">Randevu</span>
        </button>
        <Notifications />
      </div>
    </header>
  );
}

/* ── Bildirimler ────────────────────────────────────────────────────────────── */
function Notifications() {
  const { t } = useLang();
  const { appointments } = useDb();
  const [open, setOpen] = useState(false);
  const [seen, setSeen] = useState(0);
  const ref = useRef<HTMLDivElement>(null);

  // Sonradan eklenen randevular (panelden ya da randevu sayfasından) en üstte.
  const fresh = appointments.filter((a) => a.date).reverse();
  const unread = Math.max(0, fresh.length - seen);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", onDown);
    window.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        aria-label="Bildirimler"
        aria-expanded={open}
        onClick={() => {
          setOpen((o) => !o);
          setSeen(fresh.length);
        }}
        className={cn(
          "relative grid h-9 w-9 cursor-pointer place-items-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground",
          open && "bg-muted text-foreground",
        )}
      >
        <Bell className="h-[18px] w-[18px]" />
        {unread > 0 ? (
          <span className="tnum absolute right-1 top-1 grid h-4 min-w-4 place-items-center rounded-full bg-destructive px-1 text-[9px] font-bold text-white ring-2 ring-background">
            {unread}
          </span>
        ) : (
          <span className="absolute right-2.5 top-2.5 h-1.5 w-1.5 rounded-full bg-primary ring-2 ring-background" />
        )}
      </button>

      {open && (
        <div className="absolute right-0 top-11 z-30 w-[320px] max-w-[calc(100vw-1.5rem)] animate-pop overflow-hidden rounded-2xl border border-border bg-card shadow-pop">
          <div className="border-b border-border px-4 py-3">
            <p className="font-display text-[14px] font-semibold tracking-tight">Bildirimler</p>
          </div>
          <div className="max-h-[60dvh] divide-y divide-border/60 overflow-y-auto">
            {fresh.slice(0, 5).map((a) => (
              <div key={a.id} className="flex items-start gap-2.5 px-4 py-3">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-success" />
                <div className="min-w-0 text-[13px]">
                  <p className="leading-snug">
                    <span className="font-semibold">{a.client}</span>{" "}
                    <span className="text-muted-foreground">
                      {a.source === "online" ? "online randevu aldı:" : "için randevu eklendi:"}
                    </span>{" "}
                    <span className="font-medium">{t(serviceById(a.serviceId).name)}</span>
                  </p>
                  <p className="tnum text-[11px] text-muted-foreground">
                    {dayLabel(a.dayOffset)} {minutesToHHMM(a.startMin)}
                  </p>
                </div>
              </div>
            ))}
            {activity.map((a) => (
              <div key={a.id} className="flex items-start gap-2.5 px-4 py-3">
                <span
                  className={cn(
                    "mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full",
                    a.tone === "success" ? "bg-success" : a.tone === "warning" ? "bg-warning" : a.tone === "info" ? "bg-info" : "bg-muted-foreground",
                  )}
                />
                <div className="min-w-0 text-[13px]">
                  <p className="leading-snug">
                    <span className="font-semibold">{a.who}</span>{" "}
                    <span className="text-muted-foreground">{t(a.action)}</span>{" "}
                    <span className="font-medium">{a.target}</span>
                  </p>
                  <p className="tnum text-[11px] text-muted-foreground">
                    Bugün {formatDate(a.at, { hour: "2-digit", minute: "2-digit" })}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
