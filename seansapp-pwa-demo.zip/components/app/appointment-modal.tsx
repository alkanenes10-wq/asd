"use client";

import { useMemo, useState } from "react";
import { CalendarPlus } from "lucide-react";
import { Modal, FormField, selectClass } from "@/components/app/modal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLang } from "@/components/i18n/language-provider";
import { cn, formatDuration, minutesToHHMM } from "@/lib/utils";
import { dayLabel, MAX_DAY_OFFSET } from "@/lib/dates";
import { slotsForDay, formatTrPhone, isValidTrPhone } from "@/lib/booking";
import { useDb, addBooking } from "@/lib/demo/store";
import type { Appointment } from "@/lib/demo/data";

export interface AppointmentPrefill {
  client?: string;
  phone?: string;
  serviceId?: string;
  staffId?: string;
  dayOffset?: number;
  startMin?: number;
}

const SOURCES: { key: Appointment["source"]; label: string }[] = [
  { key: "phone", label: "Telefon" },
  { key: "walk-in", label: "Kapıdan" },
  { key: "online", label: "Online" },
];

/**
 * Panelden elle randevu ekleme (telefonla / kapıdan gelen hasta).
 * Boş saatler randevu sayfasıyla aynı kuraldan (`lib/booking.ts`) hesaplanır,
 * bu yüzden çakışan randevu verilemez.
 */
export function AppointmentModal({
  prefill,
  onClose,
  onSaved,
}: {
  prefill?: AppointmentPrefill;
  onClose: () => void;
  onSaved: (a: Appointment) => void;
}) {
  const { t } = useLang();
  const { services, staff, clients, appointments } = useDb();

  const [client, setClient] = useState(prefill?.client ?? "");
  const [phone, setPhone] = useState(prefill?.phone ?? "");
  const [serviceId, setServiceId] = useState(
    prefill?.serviceId && services.some((s) => s.id === prefill.serviceId) ? prefill.serviceId : services[0].id,
  );
  const [staffId, setStaffId] = useState(
    prefill?.staffId && staff.some((s) => s.id === prefill.staffId) ? prefill.staffId : staff[0].id,
  );
  const [dayOffset, setDayOffset] = useState(Math.max(0, prefill?.dayOffset ?? 0));
  const [startMin, setStartMin] = useState<number | null>(prefill?.startMin ?? null);
  const [source, setSource] = useState<Appointment["source"]>("phone");
  const [note, setNote] = useState("");
  const [touched, setTouched] = useState(false);

  const service = services.find((s) => s.id === serviceId) ?? services[0];

  const free = useMemo(
    () => slotsForDay(staffId, dayOffset, service, appointments).filter((s) => s.available),
    [staffId, dayOffset, service, appointments],
  );
  // Seçili saat artık boş değilse ilk boş saate düş — bugün için şu andan sonraki
  // ilk boş saat önerilir (geçmiş saatler listede kalır, geriye dönük kayıt için).
  const [nowMin] = useState(() => {
    const d = new Date();
    return d.getHours() * 60 + d.getMinutes();
  });
  const suggested = (dayOffset === 0 ? free.find((s) => s.min >= nowMin) : undefined) ?? free[0];
  const slot = startMin !== null && free.some((s) => s.min === startMin) ? startMin : (suggested?.min ?? null);

  const nameOk = client.trim().length >= 3;
  const phoneOk = isValidTrPhone(phone);

  function pickClient(value: string) {
    setClient(value);
    const known = clients.find((c) => c.name.toLocaleLowerCase("tr-TR") === value.trim().toLocaleLowerCase("tr-TR"));
    if (known) setPhone(known.phone);
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setTouched(true);
    if (!nameOk || !phoneOk || slot === null) return;
    const appt = addBooking({
      client,
      clientPhone: formatTrPhone(phone),
      serviceId,
      staffId,
      dayOffset,
      startMin: slot,
      note,
      source,
    });
    onSaved(appt);
  }

  return (
    <Modal title="Yeni randevu" subtitle="Telefonla ya da kapıdan gelen hastayı takvime ekleyin." onClose={onClose} wide>
      <form onSubmit={submit} className="space-y-4" noValidate>
        <div className="grid gap-3 sm:grid-cols-2">
          <FormField label="Hasta adı soyadı" htmlFor="na-ad" error={touched && !nameOk ? "Hastanın adını yazın." : null}>
            <Input
              id="na-ad"
              list="na-hastalar"
              value={client}
              onChange={(e) => pickClient(e.target.value)}
              placeholder="Ayşe Yılmaz"
              autoComplete="off"
              autoFocus={!prefill?.client}
            />
            <datalist id="na-hastalar">
              {clients.map((c) => (
                <option key={c.id} value={c.name} />
              ))}
            </datalist>
          </FormField>
          <FormField
            label="Telefon"
            htmlFor="na-tel"
            error={touched && !phoneOk ? "Geçerli bir cep telefonu girin (05XX XXX XX XX)." : null}
          >
            <Input
              id="na-tel"
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="0532 111 22 33"
              autoComplete="off"
            />
          </FormField>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <FormField label="Tedavi" htmlFor="na-tedavi">
            <select id="na-tedavi" className={selectClass} value={serviceId} onChange={(e) => setServiceId(e.target.value)}>
              {services.map((s) => (
                <option key={s.id} value={s.id}>
                  {t(s.name)} · {formatDuration(s.durationMin)}
                </option>
              ))}
            </select>
          </FormField>
          <FormField label="Hekim" htmlFor="na-hekim">
            <select id="na-hekim" className={selectClass} value={staffId} onChange={(e) => setStaffId(e.target.value)}>
              {staff.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </FormField>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <FormField label="Gün" htmlFor="na-gun">
            <select
              id="na-gun"
              className={selectClass}
              value={dayOffset}
              onChange={(e) => setDayOffset(Number(e.target.value))}
            >
              {Array.from({ length: MAX_DAY_OFFSET + 1 }, (_, i) => (
                <option key={i} value={i}>
                  {dayLabel(i)}
                </option>
              ))}
            </select>
          </FormField>
          <FormField
            label="Saat"
            htmlFor="na-saat"
            error={free.length === 0 ? "Bu gün için boş saat yok. Başka bir gün ya da hekim seçin." : null}
            hint={`${free.length} boş saat`}
          >
            <select
              id="na-saat"
              className={selectClass}
              value={slot ?? ""}
              disabled={free.length === 0}
              onChange={(e) => setStartMin(Number(e.target.value))}
            >
              {free.length === 0 && <option value="">—</option>}
              {free.map((s) => (
                <option key={s.min} value={s.min}>
                  {minutesToHHMM(s.min)} – {minutesToHHMM(s.min + service.durationMin)}
                </option>
              ))}
            </select>
          </FormField>
        </div>

        <FormField label="Randevu nasıl geldi?">
          <div className="flex gap-1.5">
            {SOURCES.map((s) => (
              <button
                key={s.key}
                type="button"
                aria-pressed={source === s.key}
                onClick={() => setSource(s.key)}
                className={cn(
                  "flex-1 cursor-pointer rounded-lg border px-3 py-2 text-[13px] font-medium transition-colors",
                  source === s.key
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border text-muted-foreground hover:bg-muted",
                )}
              >
                {s.label}
              </button>
            ))}
          </div>
        </FormField>

        <FormField label="Not (isteğe bağlı)" htmlFor="na-not">
          <Input
            id="na-not"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Şikâyet, hatırlatma…"
            maxLength={140}
          />
        </FormField>

        <div className="flex gap-2 pt-1">
          <Button type="button" variant="outline" className="flex-1" onClick={onClose}>
            Vazgeç
          </Button>
          <Button type="submit" className="flex-1" disabled={free.length === 0}>
            <CalendarPlus className="h-4 w-4" />
            Randevuyu kaydet
          </Button>
        </div>
      </form>
    </Modal>
  );
}
