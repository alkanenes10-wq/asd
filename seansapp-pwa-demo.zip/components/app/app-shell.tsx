"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { useRouter } from "next/navigation";
import { Check, Search, Mail, Phone, MessageCircle } from "lucide-react";
import appConfig from "@/app.config";
import { Sidebar } from "@/components/app/sidebar";
import { Topbar } from "@/components/app/topbar";
import { Modal } from "@/components/app/modal";
import { AppointmentModal, type AppointmentPrefill } from "@/components/app/appointment-modal";
import { useLang } from "@/components/i18n/language-provider";
import { minutesToHHMM } from "@/lib/utils";
import { dayLabel } from "@/lib/dates";
import { useDb } from "@/lib/demo/store";

/**
 * Panelin kabuğu: sidebar + üst çubuk + sayfa, ve her sayfanın paylaştığı
 * eylemler — yeni randevu modalı, hasta arama (⌘K), destek penceresi, bildirim
 * (toast) ve telefondaki menü çekmecesi.
 */
interface AppUI {
  /** Yeni randevu modalını açar (isteğe bağlı ön dolgu ile). */
  newAppointment: (prefill?: AppointmentPrefill) => void;
  /** Kısa bir onay mesajı gösterir. */
  toast: (message: string) => void;
  openSearch: () => void;
  openSupport: () => void;
  openMenu: () => void;
  /** Hastalar sayfasında açılacak hasta (aramadan seçilince). */
  focusClientId: string | null;
  clearFocusClient: () => void;
}

const AppUIContext = createContext<AppUI | null>(null);

export function useAppUI(): AppUI {
  const ctx = useContext(AppUIContext);
  if (!ctx) throw new Error("useAppUI must be used inside <AppShell>");
  return ctx;
}

const noopSubscribe = () => () => {};

export function AppShell({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  // Panel tarayıcıdaki kayıtlara ve bugünün tarihine bağlı; sunucu HTML'i ile
  // uyuşmazlık olmasın diye içerik yalnızca tarayıcıda çizilir.
  const mounted = useSyncExternalStore(noopSubscribe, () => true, () => false);
  const [apptPrefill, setApptPrefill] = useState<AppointmentPrefill | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [supportOpen, setSupportOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [focusClientId, setFocusClientId] = useState<string | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const toast = useCallback((message: string) => {
    setToastMsg(message);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastMsg(null), 2800);
  }, []);

  // ⌘K / Ctrl+K → hasta arama
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen((o) => !o);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const ui = useMemo<AppUI>(
    () => ({
      newAppointment: (prefill) => setApptPrefill(prefill ?? {}),
      toast,
      openSearch: () => setSearchOpen(true),
      openSupport: () => setSupportOpen(true),
      openMenu: () => setMenuOpen(true),
      focusClientId,
      clearFocusClient: () => setFocusClientId(null),
    }),
    [toast, focusClientId],
  );

  return (
    <AppUIContext.Provider value={ui}>
      <div className="flex h-dvh overflow-hidden">
        <Sidebar mobileOpen={menuOpen} onCloseMobile={() => setMenuOpen(false)} />
        <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
          <Topbar />
          <main className="flex-1 overflow-y-auto p-4 sm:p-5 lg:p-8">
            {mounted ? children : <PageSkeleton />}
          </main>
        </div>
      </div>

      {apptPrefill && (
        <AppointmentModal
          prefill={apptPrefill}
          onClose={() => setApptPrefill(null)}
          onSaved={(a) => {
            setApptPrefill(null);
            toast(`Randevu eklendi · ${a.client} · ${dayLabel(a.dayOffset)} ${minutesToHHMM(a.startMin)}`);
          }}
        />
      )}

      {searchOpen && (
        <SearchPalette
          onClose={() => setSearchOpen(false)}
          onPick={(id) => {
            setSearchOpen(false);
            setFocusClientId(id);
            router.push("/clients");
          }}
        />
      )}

      {supportOpen && <SupportModal onClose={() => setSupportOpen(false)} />}

      {toastMsg && (
        <div
          role="status"
          aria-live="polite"
          className="pointer-events-none fixed inset-x-0 bottom-5 z-[60] flex justify-center px-4"
        >
          <div className="flex animate-pop items-center gap-2 rounded-xl bg-foreground px-4 py-2.5 text-[13px] font-medium text-background shadow-pop">
            <span className="grid h-4 w-4 shrink-0 place-items-center rounded-full bg-success text-success-foreground">
              <Check className="h-3 w-3" strokeWidth={3} />
            </span>
            {toastMsg}
          </div>
        </div>
      )}
    </AppUIContext.Provider>
  );
}

function PageSkeleton() {
  return (
    <div className="mx-auto max-w-[1400px] animate-pulse space-y-5" aria-hidden>
      <div className="h-8 w-56 rounded-lg bg-muted" />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className="h-24 rounded-2xl bg-muted" />
        ))}
      </div>
      <div className="h-80 rounded-2xl bg-muted" />
    </div>
  );
}

/* ── Hasta arama (⌘K) ───────────────────────────────────────────────────────── */
function SearchPalette({ onClose, onPick }: { onClose: () => void; onPick: (clientId: string) => void }) {
  const { clients } = useDb();
  const [q, setQ] = useState("");

  const results = useMemo(() => {
    const needle = q.trim().toLocaleLowerCase("tr-TR");
    const digits = needle.replace(/\D/g, "");
    if (!needle) return clients.slice(0, 8);
    return clients
      .filter(
        (c) =>
          c.name.toLocaleLowerCase("tr-TR").includes(needle) ||
          c.email.toLowerCase().includes(needle) ||
          (digits.length > 2 && c.phone.replace(/\D/g, "").includes(digits)),
      )
      .slice(0, 8);
  }, [q, clients]);

  return (
    <Modal title="Hasta ara" subtitle="İsim, telefon ya da e-posta ile arayın." onClose={onClose}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (results[0]) onPick(results[0].id);
        }}
      >
        <div className="flex h-11 items-center gap-2.5 rounded-lg border border-input bg-card px-3 focus-within:border-ring focus-within:ring-2 focus-within:ring-ring">
          <Search className="h-4 w-4 shrink-0 text-primary" />
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Örn. Elif ya da 0532…"
            className="w-full bg-transparent text-sm text-foreground placeholder:text-muted-foreground/70 focus:outline-none"
          />
        </div>
      </form>
      <div className="mt-3 space-y-1">
        {results.length === 0 && (
          <p className="py-6 text-center text-[13px] text-muted-foreground">Eşleşen hasta yok.</p>
        )}
        {results.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => onPick(c.id)}
            className="flex w-full cursor-pointer items-center gap-3 rounded-lg px-2.5 py-2 text-left transition-colors hover:bg-muted"
          >
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-muted text-[11px] font-bold text-foreground/70 ring-1 ring-border">
              {c.initials}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-[13.5px] font-semibold">{c.name}</span>
              <span className="tnum block truncate text-[11.5px] text-muted-foreground">{c.phone}</span>
            </span>
            <span className="text-[11px] text-muted-foreground">{c.visits} geliş</span>
          </button>
        ))}
      </div>
    </Modal>
  );
}

/* ── Destek ─────────────────────────────────────────────────────────────────── */
function SupportModal({ onClose }: { onClose: () => void }) {
  const { t } = useLang();
  const s = appConfig.support;
  const wa = s.whatsapp.replace(/\D/g, "");
  return (
    <Modal title="Destek" subtitle={t(s.hours)} onClose={onClose}>
      <div className="space-y-2">
        <SupportLink
          href={`https://wa.me/${wa}`}
          icon={<MessageCircle className="h-4 w-4" />}
          label="WhatsApp ile yazın"
          value={s.whatsapp}
          external
        />
        <SupportLink href={`tel:${s.phone.replace(/\s/g, "")}`} icon={<Phone className="h-4 w-4" />} label="Arayın" value={s.phone} />
        <SupportLink href={`mailto:${s.email}`} icon={<Mail className="h-4 w-4" />} label="E-posta gönderin" value={s.email} />
      </div>
      <p className="mt-4 rounded-lg bg-muted px-3 py-2 text-[12px] text-muted-foreground">
        Kurulum, hasta listesi aktarımı ve eğitim desteği paketinize dahildir.
      </p>
    </Modal>
  );
}

function SupportLink({
  href,
  icon,
  label,
  value,
  external,
}: {
  href: string;
  icon: React.ReactNode;
  label: string;
  value: string;
  external?: boolean;
}) {
  return (
    <a
      href={href}
      {...(external ? { target: "_blank", rel: "noreferrer" } : {})}
      className="flex items-center gap-3 rounded-xl border border-border p-3 transition-colors hover:bg-muted"
    >
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary">{icon}</span>
      <span className="min-w-0 flex-1">
        <span className="block text-[13.5px] font-semibold">{label}</span>
        <span className="tnum block truncate text-[12px] text-muted-foreground">{value}</span>
      </span>
    </a>
  );
}
