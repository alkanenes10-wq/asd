"use client";

import { useState } from "react";
import { CheckCircle2, CircleDashed, Copy, ExternalLink, RotateCcw } from "lucide-react";
import appConfig from "@/app.config";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Icon } from "@/components/ui/icon";
import { Toggle } from "@/components/app/modal";
import { useAppUI } from "@/components/app/app-shell";
import { useLang } from "@/components/i18n/language-provider";
import { useDb, saveClinic, resetDemo, type Clinic } from "@/lib/demo/store";

export function SettingsClient({ connected }: { connected: Record<string, boolean> }) {
  const { clinic } = useDb();
  // Depodaki klinik değişince (ilk yükleme, demo sıfırlama) form baştan kurulur.
  return (
    <div className="animate-fade-in">
      <SettingsForm key={JSON.stringify(clinic)} clinic={clinic} connected={connected} />
    </div>
  );
}

function SettingsForm({ clinic, connected }: { clinic: Clinic; connected: Record<string, boolean> }) {
  const { ui } = useLang();
  const { toast } = useAppUI();
  const [name, setName] = useState(clinic.name);
  const [tagline, setTagline] = useState(clinic.tagline);
  const [phone, setPhone] = useState(clinic.phone);
  const [address, setAddress] = useState(clinic.address);
  const [confirmReset, setConfirmReset] = useState(false);

  const dirty =
    name !== clinic.name || tagline !== clinic.tagline || phone !== clinic.phone || address !== clinic.address;
  const nameOk = name.trim().length >= 2;

  const bookingUrl =
    typeof window !== "undefined" ? `${window.location.origin}${appConfig.bookingPath}` : appConfig.bookingPath;

  function save(e: React.FormEvent) {
    e.preventDefault();
    if (!nameOk) return;
    saveClinic({ name: name.trim(), tagline: tagline.trim(), phone: phone.trim(), address: address.trim() });
    toast("Klinik bilgileri kaydedildi");
  }

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(bookingUrl);
      toast("Randevu bağlantısı kopyalandı");
    } catch {
      toast("Kopyalanamadı — bağlantıyı elle seçip kopyalayın");
    }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      {/* Klinik bilgileri */}
      <Card>
        <CardHeader>
          <CardTitle>Klinik bilgileri</CardTitle>
          <p className="text-sm text-muted-foreground">
            Panelin sol üstünde ve hastaların gördüğü randevu sayfasında görünür.
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={save} className="grid gap-4 sm:grid-cols-2" noValidate>
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="k-ad">Klinik adı</Label>
              <Input id="k-ad" value={name} onChange={(e) => setName(e.target.value)} aria-invalid={!nameOk || undefined} />
              {!nameOk && <p className="text-[12px] text-destructive">Klinik adını yazın.</p>}
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="k-slogan">Kısa açıklama</Label>
              <Input id="k-slogan" value={tagline} onChange={(e) => setTagline(e.target.value)} placeholder="Ağız ve diş sağlığı · Karabük" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="k-tel">Telefon</Label>
              <Input id="k-tel" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="k-adres">Adres</Label>
              <Input id="k-adres" value={address} onChange={(e) => setAddress(e.target.value)} />
            </div>
            <div className="flex justify-end sm:col-span-2">
              <Button type="submit" disabled={!dirty || !nameOk}>
                {ui.saveChanges}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Randevu sayfası */}
      <Card>
        <CardHeader>
          <CardTitle>Randevu sayfası</CardTitle>
          <p className="text-sm text-muted-foreground">
            Bu bağlantıyı Instagram, WhatsApp ve Google işletme profilinizde paylaşın.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <Input readOnly value={bookingUrl} onFocus={(e) => e.currentTarget.select()} className="tnum min-w-0 flex-1" aria-label="Randevu bağlantısı" />
            <Button type="button" variant="outline" onClick={copyLink}>
              <Copy className="h-4 w-4" />
              Kopyala
            </Button>
            <a
              href={appConfig.bookingPath}
              target="_blank"
              rel="noreferrer"
              className="inline-flex h-10 items-center justify-center gap-2 rounded-lg border border-border bg-card px-4 text-sm font-medium transition-colors hover:bg-muted"
            >
              <ExternalLink className="h-4 w-4" />
              Aç
            </a>
          </div>
          <SettingRow
            title="Online randevu açık"
            body="Kapatırsanız hastalar sayfada yalnızca kliniğin telefonunu görür."
            checked={clinic.bookingOpen}
            onChange={(v) => {
              saveClinic({ bookingOpen: v });
              toast(v ? "Online randevu açıldı" : "Online randevu kapatıldı");
            }}
          />
          <SettingRow
            title="SMS hatırlatması"
            body="Randevudan bir gün önce 18:00'de hastaya otomatik SMS gider."
            checked={clinic.smsReminders}
            onChange={(v) => {
              saveClinic({ smsReminders: v });
              toast(v ? "SMS hatırlatması açıldı" : "SMS hatırlatması kapatıldı");
            }}
          />
        </CardContent>
      </Card>

      {/* Entegrasyonlar */}
      <Card>
        <CardHeader>
          <CardTitle>{ui.integrations}</CardTitle>
          <p className="text-sm text-muted-foreground">{ui.integrationsHint}</p>
        </CardHeader>
        <CardContent className="space-y-3">
          {appConfig.integrations.map((it) => (
            <div key={it.key} className="flex flex-wrap items-center gap-x-4 gap-y-2 rounded-lg border border-border p-4">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-muted text-muted-foreground">
                <Icon name="plug" className="h-5 w-5" />
              </span>
              <div className="min-w-0 flex-1 basis-48">
                <div className="flex items-center gap-2">
                  <p className="font-medium">{it.name}</p>
                  {it.required && <Badge tone="warning">{ui.required}</Badge>}
                </div>
                <p className="text-sm text-muted-foreground">{it.purpose}</p>
              </div>
              {connected[it.key] ? (
                <span className="inline-flex items-center gap-1.5 text-sm font-medium text-success">
                  <CheckCircle2 className="h-4 w-4" /> {ui.connected}
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground">
                  <CircleDashed className="h-4 w-4" /> {ui.demoMode}
                </span>
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Demo verisi */}
      <Card>
        <CardHeader>
          <CardTitle>Demo verisi</CardTitle>
          <p className="text-sm text-muted-foreground">
            Eklediğiniz randevu, hasta, tedavi ve hekimler bu tarayıcıda saklanır. Sıfırlayınca örnek klinik gününe dönülür.
          </p>
        </CardHeader>
        <CardContent>
          {confirmReset ? (
            <div className="flex flex-wrap items-center gap-2">
              <p className="mr-auto text-[13px] font-medium">Tüm değişiklikler silinsin mi?</p>
              <Button type="button" variant="outline" onClick={() => setConfirmReset(false)}>
                Vazgeç
              </Button>
              <Button
                type="button"
                variant="destructive"
                onClick={() => {
                  resetDemo();
                  setConfirmReset(false);
                  toast("Demo verisi sıfırlandı");
                }}
              >
                Evet, sıfırla
              </Button>
            </div>
          ) : (
            <Button type="button" variant="outline" onClick={() => setConfirmReset(true)}>
              <RotateCcw className="h-4 w-4" />
              Demoyu sıfırla
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function SettingRow({
  title,
  body,
  checked,
  onChange,
}: {
  title: string;
  body: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-border p-4">
      <div className="min-w-0 flex-1">
        <p className="text-[14px] font-medium">{title}</p>
        <p className="text-[12.5px] text-muted-foreground">{body}</p>
      </div>
      <Toggle checked={checked} onChange={onChange} label={title} />
    </div>
  );
}
