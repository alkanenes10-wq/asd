import type { NextConfig } from "next";
import { networkInterfaces } from "node:os";

/**
 * `npm run dev` çalışırken uygulamayı TELEFONDAN (aynı Wi-Fi, bilgisayarın
 * yerel IP'si — ör. http://192.168.1.34:3000) açabilmek için.
 *
 * Next.js 16 geliştirme modunda, `localhost` dışındaki adreslerden gelen
 * isteklere dev kaynaklarını vermez; bu izin olmadan sayfa telefonda görünür
 * ama etkileşim (JavaScript) yüklenmediği için HİÇBİR DÜĞME ÇALIŞMAZ.
 * Bu bilgisayarın ağ adresleri ve yaygın yerel ağ aralıkları burada izinlidir.
 * Yalnızca `next dev`i etkiler; yayındaki (Vercel) sürümle ilgisi yoktur.
 */
function lanOrigins(): string[] {
  const own = Object.values(networkInterfaces())
    .flat()
    .filter((n) => n && n.family === "IPv4" && !n.internal)
    .map((n) => n!.address);
  return [...new Set([...own, "192.168.*.*", "10.*.*.*", "172.*.*.*", "*.local"])];
}

const isStaticExport = Boolean(process.env.STATIC_EXPORT);

const nextConfig: NextConfig = {
  allowedDevOrigins: lanOrigins(),

  // `STATIC_EXPORT=1 npm run build` → uygulamayı `out/` altına statik HTML olarak
  // çıkarır (her sayfa için bir .html + `_next/` varlıkları). Normal
  // `npm run dev` / `npm run build` bundan etkilenmez.
  ...(isStaticExport
    ? { output: "export" as const, images: { unoptimized: true } }
    : {}),

  // ── PWA başlıkları ────────────────────────────────────────────────────────
  // Service worker dosyası ASLA önbellekte tutulmamalı; yoksa yeni sürüm
  // yayına alındığında kullanıcılar eski sw.js ile takılı kalır.
  // `output: export` modunda headers() desteklenmediği için orada atlanır.
  ...(isStaticExport
    ? {}
    : {
        async headers() {
          return [
            {
              source: "/sw.js",
              headers: [
                {
                  key: "Cache-Control",
                  value: "public, max-age=0, must-revalidate",
                },
                { key: "Service-Worker-Allowed", value: "/" },
              ],
            },
            {
              source: "/manifest.webmanifest",
              headers: [
                {
                  key: "Cache-Control",
                  value: "public, max-age=0, must-revalidate",
                },
              ],
            },
          ];
        },
      }),
};

export default nextConfig;
