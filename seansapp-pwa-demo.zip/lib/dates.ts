/**
 * Gün yardımcıları. Panel ve randevu sayfası günleri "bugüne göre fark"
 * (`dayOffset`) ile taşır; kalıcı kayıtlar ise mutlak tarih (YYYY-AA-GG) tutar.
 */
import { LOCALE } from "@/lib/utils";

/** Panelde gezilebilen en erken / en geç gün. */
export const MIN_DAY_OFFSET = -1;
export const MAX_DAY_OFFSET = 6;

function pad(n: number) {
  return String(n).padStart(2, "0");
}

/** Bugünden `offset` gün sonrası, yerel gece yarısı. */
export function dateForOffset(offset: number): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() + offset);
  return d;
}

/** → "2026-10-02" (yerel saat). */
export function isoForOffset(offset: number): string {
  const d = dateForOffset(offset);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/** "2026-10-02" → bugüne göre gün farkı. */
export function offsetForIso(iso: string): number {
  const [y, m, d] = iso.split("-").map(Number);
  if (!y || !m || !d) return 0;
  const target = new Date(y, m - 1, d).getTime();
  return Math.round((target - dateForOffset(0).getTime()) / 86_400_000);
}

/** "2 Eki Cum" */
export function shortDate(offset: number): string {
  return new Intl.DateTimeFormat(LOCALE, { day: "numeric", month: "short", weekday: "short" }).format(
    dateForOffset(offset),
  );
}

/** Dün / Bugün / Yarın, diğer günlerde "5 Eki Pzt". */
export function dayLabel(offset: number): string {
  if (offset === -1) return "Dün";
  if (offset === 0) return "Bugün";
  if (offset === 1) return "Yarın";
  return shortDate(offset);
}

/** "Bugün · 2 Eki Cum" — başlıklarda kullanılır. */
export function dayLabelLong(offset: number): string {
  if (offset >= -1 && offset <= 1) return `${dayLabel(offset)} · ${shortDate(offset)}`;
  return shortDate(offset);
}
