"use client";

/**
 * Demo modunun deposu.
 *
 * Supabase bağlı değilken panelde yapılan HER değişiklik (yeni randevu, durum
 * değişikliği, tedavi / hekim / hasta ekleme-düzenleme, klinik bilgileri)
 * tarayıcının localStorage'ında durur. Böylece demo sırasında eklenen bir
 * tedavi hem panelde hem `/randevu` sayfasında anında görünür ve sayfa
 * yenilense bile kaybolmaz.
 *
 * Supabase bağlandığında yalnızca bu dosyanın içi değişir; çağıran yerler
 * (`useDb`, `addBooking`, `saveService`…) aynı kalır.
 */

import { useSyncExternalStore } from "react";
import { initials } from "@/lib/utils";
import { isoForOffset, offsetForIso } from "@/lib/dates";
import {
  appointments as seedAppointments,
  services as seedServices,
  staff as seedStaff,
  clients as seedClients,
  bookingPage,
  setLiveCatalog,
  type Appointment,
  type ApptStatus,
  type Client,
  type Service,
  type Staff,
} from "@/lib/demo/data";

const STORAGE_KEY = "seansapp:db:v2";

export interface Clinic {
  name: string;
  tagline: string;
  phone: string;
  address: string;
  /** Randevudan bir gün önce SMS hatırlatması. */
  smsReminders: boolean;
  /** Randevu sayfası yayında mı? */
  bookingOpen: boolean;
}

const DEFAULT_CLINIC: Clinic = {
  name: bookingPage.business,
  tagline: bookingPage.tagline.tr,
  phone: "+90 370 000 00 00",
  address: "Bayır Mah. Hürriyet Cad. No: 12, Merkez / Karabük",
  smsReminders: true,
  bookingOpen: true,
};

/** localStorage'a yazılan ham durum. */
interface Persisted {
  services: Service[];
  staff: Staff[];
  /** Panelden eklenen hastalar (demo hastalarına eklenir). */
  clients: Client[];
  /** Panelden / randevu sayfasından eklenen randevular (mutlak tarihli). */
  bookings: Appointment[];
  /** Randevu durumu değişiklikleri: id → durum. */
  status: Record<string, ApptStatus>;
  /** İptal edilen randevuların id'leri. */
  removed: string[];
  clinic: Clinic;
}

/** Bileşenlerin okuduğu, türetilmiş görünüm. */
export interface Db {
  services: Service[];
  staff: Staff[];
  clients: Client[];
  appointments: Appointment[];
  clinic: Clinic;
}

function defaults(): Persisted {
  return {
    services: seedServices,
    staff: seedStaff,
    clients: [],
    bookings: [],
    status: {},
    removed: [],
    clinic: DEFAULT_CLINIC,
  };
}

function derive(p: Persisted): Db {
  const removed = new Set(p.removed);
  const booked = p.bookings.map((b) => (b.date ? { ...b, dayOffset: offsetForIso(b.date) } : b));
  const appointments = [...seedAppointments, ...booked]
    .filter((a) => !removed.has(a.id))
    .map((a) => (p.status[a.id] ? { ...a, status: p.status[a.id] } : a));
  return {
    services: p.services,
    staff: p.staff,
    clients: [...p.clients, ...seedClients],
    appointments,
    clinic: p.clinic,
  };
}

/* ── Durum ──────────────────────────────────────────────────────────────────
   Sunucuda ve ilk (hydration) render'da HER ZAMAN varsayılan veri kullanılır;
   tarayıcıdaki kayıtlar ilk abonelikte yüklenir. Böylece sunucu HTML'i ile
   istemci ilk render'ı birebir aynı olur. */

const SERVER_DB: Db = derive(defaults());

let state: Persisted = defaults();
let view: Db = SERVER_DB;
let loaded = false;

const listeners = new Set<() => void>();

function emit() {
  for (const l of listeners) l();
}

function apply(next: Persisted) {
  state = next;
  view = derive(next);
  setLiveCatalog(next.services, next.staff);
}

function readStorage(): Persisted {
  const base = defaults();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return base;
    const p = JSON.parse(raw) as Partial<Persisted>;
    return {
      services: Array.isArray(p.services) && p.services.length ? p.services : base.services,
      staff: Array.isArray(p.staff) && p.staff.length ? p.staff : base.staff,
      clients: Array.isArray(p.clients) ? p.clients : [],
      bookings: Array.isArray(p.bookings) ? p.bookings : [],
      status: p.status && typeof p.status === "object" ? p.status : {},
      removed: Array.isArray(p.removed) ? p.removed : [],
      clinic: { ...base.clinic, ...(p.clinic ?? {}) },
    };
  } catch {
    // Gizli sekme ya da bozuk kayıt: depo yokmuş gibi davran.
    return base;
  }
}

function ensureLoaded() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  apply(readStorage());
}

function commit(next: Persisted) {
  apply(next);
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    // Depolama kullanılamıyorsa değişiklik yine de bu oturumda görünsün.
  }
  emit();
}

function onStorage(e: StorageEvent) {
  // Başka bir sekmede (ör. /randevu) yapılan değişiklik bu sekmeyi de tazelesin.
  if (e.key !== null && e.key !== STORAGE_KEY) return;
  apply(readStorage());
  emit();
}

function subscribe(listener: () => void) {
  const before = view;
  ensureLoaded();
  listeners.add(listener);
  if (listeners.size === 1) window.addEventListener("storage", onStorage);
  // İlk yüklemede veri değiştiyse daha önce abone olanları da haberdar et.
  if (view !== before) queueMicrotask(emit);
  return () => {
    listeners.delete(listener);
    if (listeners.size === 0) window.removeEventListener("storage", onStorage);
  };
}

const getSnapshot = () => view;
const getServerSnapshot = () => SERVER_DB;

/* ── Okuma ──────────────────────────────────────────────────────────────────── */

/** Panelin ve randevu sayfasının okuduğu canlı veri. */
export function useDb(): Db {
  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}

/** Demo verisi + sonradan eklenen randevular (iptaller düşülmüş). */
export function useAllAppointments(): Appointment[] {
  return useDb().appointments;
}

/* ── Randevular ─────────────────────────────────────────────────────────────── */

export interface BookingInput {
  client: string;
  clientPhone: string;
  serviceId: string;
  staffId: string;
  dayOffset: number;
  startMin: number;
  note?: string;
  /** Varsayılan: "online" (randevu sayfası). Panelden eklenenler telefon/kapıdan. */
  source?: Appointment["source"];
}

/**
 * Benzersiz kayıt anahtarı. `crypto.randomUUID()` yalnızca güvenli bağlamda
 * (https ya da localhost) tanımlıdır; klinik sayfayı telefondan yerel ağ IP'siyle
 * açtığında yoktur ve çağrı hata fırlatır. Bu yüzden yedeği var.
 */
function newId(prefix: string): string {
  const c = globalThis.crypto;
  if (typeof c?.randomUUID === "function") return `${prefix}-${c.randomUUID()}`;
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

const sameName = (a: string, b: string) =>
  a.trim().toLocaleLowerCase("tr-TR") === b.trim().toLocaleLowerCase("tr-TR");

/** Yeni bir randevu kaydeder ve oluşturulan kaydı döndürür. */
export function addBooking(input: BookingInput): Appointment {
  ensureLoaded();
  const name = input.client.trim();
  const known = view.clients.find((c) => sameName(c.name, name));
  const appt: Appointment = {
    id: newId("web"),
    client: name,
    clientInitials: initials(name),
    clientPhone: input.clientPhone,
    serviceId: input.serviceId,
    staffId: input.staffId,
    dayOffset: input.dayOffset,
    date: isoForOffset(input.dayOffset),
    startMin: input.startMin,
    status: "booked",
    price: 0,
    paid: false,
    source: input.source ?? "online",
    pastVisits: known?.visits ?? 0,
    ...(input.note?.trim() ? { note: { tr: input.note.trim(), en: input.note.trim() } } : {}),
  };
  // İlk kez gelen hasta, hasta listesine de düşer.
  const clients = known
    ? state.clients
    : [
        {
          id: newId("c"),
          name,
          initials: initials(name),
          email: "",
          phone: input.clientPhone,
          visits: 0,
          spend: 0,
          lastVisit: isoForOffset(0),
          tag: "new" as const,
        },
        ...state.clients,
      ];
  commit({ ...state, bookings: [...state.bookings, appt], clients });
  return appt;
}

/** Randevunun durumunu değiştirir (geldi / tamamlandı / gelmedi…). */
export function setAppointmentStatus(id: string, status: ApptStatus) {
  ensureLoaded();
  commit({ ...state, status: { ...state.status, [id]: status } });
}

/** Randevuyu iptal eder — takvimden ve listelerden kalkar. */
export function cancelAppointment(id: string) {
  ensureLoaded();
  if (state.bookings.some((b) => b.id === id)) {
    commit({ ...state, bookings: state.bookings.filter((b) => b.id !== id) });
  } else {
    commit({ ...state, removed: [...state.removed, id] });
  }
}

/* ── Hastalar ───────────────────────────────────────────────────────────────── */

export function addClient(input: { name: string; phone: string; email?: string }): Client {
  ensureLoaded();
  const name = input.name.trim();
  const client: Client = {
    id: newId("c"),
    name,
    initials: initials(name),
    email: input.email?.trim() ?? "",
    phone: input.phone,
    visits: 0,
    spend: 0,
    lastVisit: isoForOffset(0),
    tag: "new",
  };
  commit({ ...state, clients: [client, ...state.clients] });
  return client;
}

/* ── Tedaviler ──────────────────────────────────────────────────────────────── */

export function saveService(input: Omit<Service, "id" | "price" | "deposit" | "bookings30d"> & { id?: string }) {
  ensureLoaded();
  if (input.id) {
    commit({
      ...state,
      services: state.services.map((s) => (s.id === input.id ? { ...s, ...input, id: s.id } : s)),
    });
  } else {
    const svc: Service = { ...input, id: newId("s"), price: 0, deposit: 0, bookings30d: 0 };
    commit({ ...state, services: [...state.services, svc] });
  }
}

/** Randevusu olan tedavi silinemez → false döner. */
export function deleteService(id: string): boolean {
  ensureLoaded();
  if (state.services.length <= 1) return false;
  if (view.appointments.some((a) => a.serviceId === id)) return false;
  commit({ ...state, services: state.services.filter((s) => s.id !== id) });
  return true;
}

/* ── Hekimler ───────────────────────────────────────────────────────────────── */

export function saveStaff(input: Omit<Staff, "id" | "initials" | "utilization" | "online"> & { id?: string }) {
  ensureLoaded();
  // Unvanlar baş harflere karışmasın: "Dr. Dt. Aylin Demir" → "AD".
  const ini = initials(input.name.trim().replace(/^((Prof|Doç|Dr|Dt|Uzm)\.\s*)+/i, ""));
  if (input.id) {
    commit({
      ...state,
      staff: state.staff.map((s) => (s.id === input.id ? { ...s, ...input, id: s.id, initials: ini } : s)),
    });
  } else {
    const person: Staff = { ...input, id: newId("st"), initials: ini, utilization: 0, online: true };
    commit({ ...state, staff: [...state.staff, person] });
  }
}

/** Randevusu olan hekim silinemez → false döner. */
export function deleteStaff(id: string): boolean {
  ensureLoaded();
  if (state.staff.length <= 1) return false;
  if (view.appointments.some((a) => a.staffId === id)) return false;
  commit({ ...state, staff: state.staff.filter((s) => s.id !== id) });
  return true;
}

/* ── Klinik ─────────────────────────────────────────────────────────────────── */

export function saveClinic(patch: Partial<Clinic>) {
  ensureLoaded();
  commit({ ...state, clinic: { ...state.clinic, ...patch } });
}

/** Demoyu ilk haline döndürür — tüm yerel değişiklikleri siler. */
export function resetDemo() {
  loaded = true;
  apply(defaults());
  try {
    window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    /* yoksay */
  }
  emit();
}
